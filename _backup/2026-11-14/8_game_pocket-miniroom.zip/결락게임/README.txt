결락 게임 백업 (2026-11-14, Claude)
- pocket_미니룸/index.html : 사이트에 연결된 포켓 미니룸(방 꾸미기). 파일 하나로 동작, 이미지는 코드로 그림.
- miniroom_v0.2_원본.html : 처음 만든 Y2K 미니룸 앱 v0.2 원본.
- play_게임모니터_v13.html : 90년대 CRT 모니터 + 칩튠 BGM 화면 (사이트 폴더 v13 안에서 ../pocket/ 을 불러옴).
- capture_room_*.png, s_*.png : 방 꾸미기 화면 캡처.
사이트 주소: https://k75080335-byte.github.io/allones/gyeollak/pocket/
